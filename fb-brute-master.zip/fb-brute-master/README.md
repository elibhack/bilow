fb-brute
fb-brute Version 1.0 can crack into Facebook Database 100% without Interruption By Facebook Firewall
This program is for educational purposes only.
Don't attack people facebook accounts it's illegal !
If you want to crack into someone's account, you must have the permission of the user.
Mauritania Attacker is not responsible
Whit is a fb-brute
I have written lots of facebook hacking art icle like hack facebook using android smartphone,open source tools,python and perl script etc.. But Toady I'will tell you about hacking in Facebook Using Brute force attack.
In brute force attack method,tool try all combination of password to provide access of victim account Brute force attack is the only successful method to hack facebook account. Hack Facebook Account Password Using Brute
Download&Install
git clone https://github.com/lunnar211/fb-brute
cd facebook-cracker
chmod +x fb-brute
python fb-brute.py
